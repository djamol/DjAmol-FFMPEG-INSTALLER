##
# If you get  [ffmpeg_movie.lo] Error 1 when compiling ffmpeg-php
# go to folder command: cd ffmpeg-php*
# command : nano 
#nano ffmpeg_movie.c
#Changes in ffmpeg_movie.c:
#row 311: list_entry *le; to zend_rsrc_list_entry *le;
#row 346: list_entry new_le; to zend_rsrc_list_entry new_le;
#row 360: hashkey_length+1, (void *)&new_le, sizeof(list_entry), to hashkey_length+1, (void *)&new_le,sizeof(zend_rsrc_list_entry),
##


# rpm file for ffmpeg
#rpm -ivh http://apt.sw.be/redhat/el5/en/i386/rpmforge/RPMS/rpmforge-release-0.3.6-1.el5.rf.i386.rpm
#   OR
rpm -ivh ffmpeg.rpm


yum install ffmpeg ffmpeg-devel ffmpeg-libpostproc
#yum install php-gd php-devel
tar -xjf ffmpeg-php*
cd ffmpeg-php*
phpize
./configure && make
make test
make install
yum install nano
echo -e 'if error ffmpeg_movie.c\nnano ffmpeg_movie.c\nrow 311: list_entry *le to zend_rsrc_list_entry *le\nrow 346: list_entry new_le to zend_rsrc_list_entry new_le\n#row 360: hashkey_length+1, (void *)&new_le, sizeof(list_entry), to hashkey_length+1, (void *)&new_le,sizeof(zend_rsrc_list_entry),
';

#nano /etc/php.ini
#edit php.ini
#And Put this two line
#[ffmpeg]
#extension=ffmpeg.so
#And restart httpd/apache
echo -e '[ffmpeg]\nextension=ffmpeg.so' >> /local/lib/php.ini
service httpd restart
