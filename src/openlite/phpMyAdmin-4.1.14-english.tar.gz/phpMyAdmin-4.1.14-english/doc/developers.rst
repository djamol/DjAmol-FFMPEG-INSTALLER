.. _developers:

Developers Information
======================

phpMyAdmin is Open Source, so you're invited to contribute to it. Many
great features have been written by other people and you too can help
to make phpMyAdmin a useful tool.

You can check out all the possibilities to contribute in the
`contribute section on our website 
<http://www.phpmyadmin.net/home_page/improve.php>`_.